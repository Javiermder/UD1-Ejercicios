[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "EjMaui")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "EjMaui.Pages")]
