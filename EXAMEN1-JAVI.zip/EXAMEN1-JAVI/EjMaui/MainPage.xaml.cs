﻿namespace EjMaui
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();
        }


        private void CantidadSlider_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            int cant = Convert.ToInt32(CantidadSlider.Value);

            cantidadLabel.Text = $"{cant} pizzas";
        }
    }

}
